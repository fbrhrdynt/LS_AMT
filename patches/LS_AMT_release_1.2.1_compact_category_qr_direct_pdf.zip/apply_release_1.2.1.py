#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json
import shutil

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent


def read(rel):
    p = ROOT / rel
    if not p.is_file():
        raise SystemExit(f"ABORT: missing {rel}")
    return p.read_text(encoding="utf-8")


def write(rel, text):
    (ROOT / rel).write_text(text, encoding="utf-8")


def replace_once(rel, old, new):
    text = read(rel)
    count = text.count(old)
    if count != 1:
        raise SystemExit(
            f"ABORT: marker mismatch in {rel}: expected 1 occurrence, found {count}"
        )
    write(rel, text.replace(old, new, 1))


history_path = ROOT / "backend/version_history.json"
history = json.loads(history_path.read_text(encoding="utf-8"))
versions = history.get("versions") or []
latest = str(versions[0].get("version")) if versions else ""

if latest != "1.2.0":
    raise SystemExit(
        f"ABORT: AMT 1.2.1 requires latest documented version 1.2.0; found {latest or 'none'}"
    )

if any(str(item.get("version")) == "1.2.1" for item in versions):
    raise SystemExit("ABORT: version 1.2.1 already exists")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = Path("/tmp") / f"amt-release-1.2.1-backup-{stamp}"
backup.mkdir(parents=True, exist_ok=True)

for rel in (
    "backend/public_inventory_category_routes.py",
    "backend/version_history.json",
    "frontend/src/components/InventoryPublicAccess.jsx",
    "README.md",
):
    src = ROOT / rel
    if not src.is_file():
        raise SystemExit(f"ABORT: missing {rel}")
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

shutil.copy2(
    BASE / "payload/frontend/src/components/InventoryPublicAccess.jsx",
    ROOT / "frontend/src/components/InventoryPublicAccess.jsx",
)

replace_once(
    "backend/public_inventory_category_routes.py",
    '''def _public_url(token_id: str) -> str:\n    return (\n        f"{PUBLIC_BASE_URL}/q/inventory-category/"\n        f"{_public_token(token_id)}"\n    )\n''',
    '''def _public_url(token_id: str) -> str:\n    token = _public_token(token_id)\n\n    return (\n        f"{PUBLIC_BASE_URL}/api/public/inventory-category/"\n        f"{token}/export.pdf?download=true"\n    )\n''',
)

replace_once(
    "backend/public_inventory_category_routes.py",
    '''async def public_inventory_category_pdf(\n    token: str,\n    request: Request,\n    q: str = Query(\n''',
    '''async def public_inventory_category_pdf(\n    token: str,\n    request: Request,\n    download: bool = Query(False),\n    q: str = Query(\n''',
)

replace_once(
    "backend/public_inventory_category_routes.py",
    '''    return Response(\n        content=data,\n        media_type="application/pdf",\n        headers={\n            **PUBLIC_HEADERS,\n            "Content-Disposition": (\n                f'inline; filename="amt-inventory-{name}.pdf"'\n            ),\n        },\n    )''',
    '''    disposition = (\n        "attachment"\n        if download\n        else "inline"\n    )\n\n    return Response(\n        content=data,\n        media_type="application/pdf",\n        headers={\n            **PUBLIC_HEADERS,\n            "Content-Disposition": (\n                f'{disposition}; filename="amt-inventory-{name}.pdf"'\n            ),\n        },\n    )''',
)

release = {
    "version": "1.2.1",
    "status": "stable",
    "title": "Compact Category QR Manager & Direct PDF Links",
    "summary": (
        "Refined the Inventory category QR interface for large category lists "
        "and changed category QR/Public Links to deliver the category PDF directly."
    ),
    "changes": [
        "Inventory QR/Public Link by Category is collapsed by default behind one View QR Public Link Category action.",
        "The category list appears only after the section is opened.",
        "Category details and QR/link actions appear only after a category is selected.",
        "The category list uses a bounded scroll area so large installations do not expand the Inventory page excessively.",
        "Added category search for installations with many Inventory categories.",
        "Only one category detail panel can be open at a time.",
        "Category QR codes now point directly to the branded Inventory PDF for that category.",
        "Open Public Link now opens/downloads the selected category PDF directly instead of opening the public HTML page.",
        "Copy Link now copies the direct public category PDF link.",
        "Existing signed-token, reset, disable/enable, and rate-limit protections remain in place.",
        "No database migration is required.",
    ],
}

history["versions"] = [release, *versions]
history_path.write_text(
    json.dumps(history, indent=2, ensure_ascii=True) + "\n",
    encoding="utf-8",
)

replace_once(
    "README.md",
    '''AMT uses semantic versions for production releases. These are product-facing summaries through **1.2.0**.\n\n### 1.2.0 - Category Cabinet QR & Granular Inventory Permissions\n''',
    '''AMT uses semantic versions for production releases. These are product-facing summaries through **1.2.1**.\n\n### 1.2.1 - Compact Category QR Manager & Direct PDF Links\n\n- Inventory category QR management is collapsed behind **View QR Public Link Category**.\n- Category rows are shown only when the section is opened.\n- QR/link details are shown only for the currently selected category.\n- Category search and a bounded scroll area keep the page compact even with many categories.\n- Category QR codes now open the branded **Inventory PDF for that category directly**.\n- **Open Public Link** opens/downloads the selected category PDF instead of the public HTML page.\n- **Copy Link** copies the direct signed category PDF URL.\n- Existing token, reset, disable/enable, and rate-limit protections remain in place.\n- No database migration is required.\n\n### 1.2.0 - Category Cabinet QR & Granular Inventory Permissions\n''',
)

print("AMT 1.2.1 compact category QR/direct PDF patch applied successfully.")
print(f"Backup: {backup}")
print("Release: 1.2.1 stable")
