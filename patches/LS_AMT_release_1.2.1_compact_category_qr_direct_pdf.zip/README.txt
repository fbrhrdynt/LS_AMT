AMT 1.2.1

Revision of the unreleased 1.2.0 category QR feature.

Changes:
- Compact/collapsible category QR manager
- Searchable, scrollable category list
- One selected category detail at a time
- QR/Public Link points directly to category PDF
- No database migration
