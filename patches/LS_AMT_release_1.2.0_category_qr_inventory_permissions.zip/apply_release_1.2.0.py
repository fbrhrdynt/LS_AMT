#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json
import shutil

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent

def read(rel):
    p = ROOT / rel
    if not p.is_file():
        raise SystemExit(f'ABORT: missing {rel}')
    return p.read_text(encoding='utf-8')

def write(rel, text):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')

def replace_once(rel, old, new):
    text = read(rel)
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'ABORT: marker mismatch in {rel}: expected 1 occurrence, found {count}')
    write(rel, text.replace(old, new, 1))

history_path = ROOT / 'backend/version_history.json'
history = json.loads(history_path.read_text(encoding='utf-8'))
versions = history.get('versions') or []
latest = str(versions[0].get('version')) if versions else ''
if latest != '1.1.14':
    raise SystemExit(f'ABORT: AMT 1.2.0 requires latest documented version 1.1.14; found {latest or "none"}')
if any(str(item.get('version')) == '1.2.0' for item in versions):
    raise SystemExit('ABORT: version 1.2.0 already exists')

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = Path('/tmp') / f'amt-release-1.2.0-backup-{stamp}'
backup.mkdir(parents=True, exist_ok=True)
targets = (
    'backend/auth.py',
    'backend/inventory_routes.py',
    'backend/export_routes.py',
    'backend/server.py',
    'backend/version_history.json',
    'deploy/amt-update-runner',
    'frontend/src/App.js',
    'frontend/src/context/AuthContext.jsx',
    'frontend/src/pages/Inventory.jsx',
    'frontend/src/pages/Users.jsx',
    'frontend/src/components/InventoryPublicAccess.jsx',
    'README.md',
)
for rel in targets:
    src = ROOT / rel
    if not src.is_file():
        raise SystemExit(f'ABORT: missing {rel}')
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

new_files = (
    'backend/public_inventory_category_routes.py',
    'frontend/src/components/InventoryPermissionEditor.jsx',
    'frontend/src/pages/PublicInventoryCategory.jsx',
)
for rel in new_files:
    dest = ROOT / rel
    if dest.exists():
        raise SystemExit(f'ABORT: {rel} already exists; review before applying')
    src = BASE / 'payload' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)

# Replace category QR manager UI.
shutil.copy2(
    BASE / 'payload/frontend/src/components/InventoryPublicAccess.jsx',
    ROOT / 'frontend/src/components/InventoryPublicAccess.jsx',
)

replace_once('backend/auth.py', 'def public_user(user: dict) -> dict:\n', 'MENU_PERMISSION_OPERATIONS = (\n    "view",\n    "add",\n    "edit",\n    "delete",\n    "public",\n)\n\n\ndef _normalize_permission_values(\n    values,\n) -> list[str]:\n    selected = set(\n        values or []\n    )\n\n    normalized = [\n        operation\n        for operation in MENU_PERMISSION_OPERATIONS\n        if operation in selected\n    ]\n\n    if (\n        normalized\n        and "view" not in normalized\n    ):\n        normalized.insert(\n            0,\n            "view",\n        )\n\n    return normalized\n\n\ndef normalize_menu_permissions(\n    user: dict,\n) -> dict[str, list[str]]:\n    if (\n        user.get("role")\n        == "master_admin"\n    ):\n        menus = list(\n            MENU_KEYS\n        )\n    elif isinstance(\n        user.get("menu_access"),\n        list,\n    ):\n        menus = [\n            key\n            for key in MENU_KEYS\n            if key\n            in user.get(\n                "menu_access",\n                [],\n            )\n        ]\n    else:\n        menus = list(\n            MENU_KEYS\n        )\n\n    raw = user.get(\n        "menu_permissions"\n    )\n\n    result = {}\n\n    for key in menus:\n        if (\n            isinstance(raw, dict)\n            and key in raw\n        ):\n            result[key] = (\n                _normalize_permission_values(\n                    raw.get(key)\n                )\n            )\n        else:\n            result[key] = list(\n                MENU_PERMISSION_OPERATIONS\n            )\n\n    return result\n\n\ndef has_menu_permission(\n    user: dict,\n    menu_key: str,\n    operation: str = "view",\n) -> bool:\n    if not user:\n        return False\n\n    if (\n        user.get("role")\n        == "master_admin"\n    ):\n        return True\n\n    if (\n        menu_key\n        not in MENU_KEYS\n        or operation\n        not in MENU_PERMISSION_OPERATIONS\n    ):\n        return False\n\n    permissions = (\n        normalize_menu_permissions(\n            user\n        )\n    )\n\n    return (\n        operation\n        in permissions.get(\n            menu_key,\n            [],\n        )\n    )\n\n\ndef public_user(user: dict) -> dict:\n')

replace_once('backend/auth.py', '    else:\n        user["menu_access"] = [\n            key\n            for key in (user.get("menu_access") or [])\n            if key in MENU_KEYS\n        ]\n\n    return user\n', '    else:\n        user["menu_access"] = [\n            key\n            for key in (user.get("menu_access") or [])\n            if key in MENU_KEYS\n        ]\n\n    user["menu_permissions"] = (\n        normalize_menu_permissions(\n            user\n        )\n    )\n\n    return user\n')

replace_once('backend/auth.py', 'def require_roles(*roles):\n', 'def require_menu_permission(\n    menu_key: str,\n    operation: str = "view",\n):\n    async def dependency(\n        user: dict = Depends(\n            get_current_user\n        ),\n    ) -> dict:\n        if not has_menu_permission(\n            user,\n            menu_key,\n            operation,\n        ):\n            raise HTTPException(\n                status_code=403,\n                detail=(\n                    "Insufficient menu permission: "\n                    f"{menu_key}.{operation}"\n                ),\n            )\n\n        return user\n\n    return dependency\n\n\ndef require_roles(*roles):\n')

replace_once('backend/auth.py', 'class RoleProfileAssignmentBody(\n    BaseModel\n):\n', 'class MenuPermissionsBody(\n    BaseModel\n):\n    menu_access: list[str] = Field(\n        default_factory=list\n    )\n    menu_permissions: dict[\n        str,\n        list[str],\n    ] = Field(\n        default_factory=dict\n    )\n\n\nclass RoleProfileAssignmentBody(\n    BaseModel\n):\n')

replace_once('backend/auth.py', '@users_router.get("")\nasync def list_users(\n', 'def _validate_delegated_menu_permissions(\n    actor: dict,\n    menu_access,\n    requested,\n) -> dict[str, list[str]]:\n    access = (\n        _validate_delegated_menu_access(\n            actor,\n            menu_access,\n        )\n    )\n\n    actor_permissions = (\n        normalize_menu_permissions(\n            actor\n        )\n    )\n\n    requested = (\n        requested\n        if isinstance(\n            requested,\n            dict,\n        )\n        else {}\n    )\n\n    result = {}\n\n    for key in access:\n        values = (\n            requested.get(\n                key,\n                MENU_PERMISSION_OPERATIONS,\n            )\n        )\n\n        operations = (\n            _normalize_permission_values(\n                values\n            )\n        )\n\n        allowed = set(\n            actor_permissions.get(\n                key,\n                [],\n            )\n        )\n\n        forbidden = [\n            operation\n            for operation in operations\n            if operation\n            not in allowed\n        ]\n\n        if forbidden:\n            raise HTTPException(\n                status_code=403,\n                detail=(\n                    "You can only grant permissions "\n                    "that are available to your own account"\n                ),\n            )\n\n        result[key] = operations\n\n    return result\n\n\n@users_router.get("")\nasync def list_users(\n')

replace_once('backend/auth.py', 'class NewUserBody(BaseModel):\n', '@users_router.patch(\n    "/{user_id}/permissions"\n)\nasync def set_menu_permissions(\n    user_id: str,\n    body: MenuPermissionsBody,\n    user: dict = Depends(\n        require_roles(\n            "admin"\n        )\n    ),\n):\n    if user_id == user["id"]:\n        raise HTTPException(\n            status_code=400,\n            detail=(\n                "Cannot change your own "\n                "access permissions"\n            ),\n        )\n\n    target = await db.users.find_one(\n        {"id": user_id}\n    )\n\n    if not target:\n        raise HTTPException(\n            status_code=404,\n            detail="User not found",\n        )\n\n    if not _can_manage_target(\n        user,\n        target,\n    ):\n        raise HTTPException(\n            status_code=403,\n            detail=(\n                "You cannot manage a user "\n                "at this role level"\n            ),\n        )\n\n    if (\n        _effective_role(target)\n        == "master_admin"\n    ):\n        raise HTTPException(\n            status_code=400,\n            detail=(\n                "Master Admin permissions "\n                "are always unrestricted"\n            ),\n        )\n\n    access = (\n        _validate_delegated_menu_access(\n            user,\n            body.menu_access,\n        )\n    )\n\n    current_permissions = (\n        normalize_menu_permissions(\n            target\n        )\n    )\n\n    merged = {\n        **current_permissions,\n        **(\n            body.menu_permissions\n            or {}\n        ),\n    }\n\n    permissions = (\n        _validate_delegated_menu_permissions(\n            user,\n            access,\n            merged,\n        )\n    )\n\n    updated = (\n        await db.users.find_one_and_update(\n            {"id": user_id},\n            {\n                "$set": {\n                    "menu_access": access,\n                    "menu_permissions":\n                        permissions,\n                }\n            },\n            return_document=(\n                ReturnDocument.AFTER\n            ),\n        )\n    )\n\n    await audit_log(\n        "user",\n        user_id,\n        "user.menu_permissions",\n        user,\n        (\n            "Updated menu permissions; "\n            "Inventory="\n            + ",".join(\n                permissions.get(\n                    "inv",\n                    [],\n                )\n            )\n        ),\n    )\n\n    return public_user(\n        updated\n    )\n\n\nclass NewUserBody(BaseModel):\n')

replace_once('backend/auth.py', '    menu_access: list[str] = Field(\n        default_factory=lambda: list(\n            MENU_KEYS\n        )\n    )\n\n\n@users_router.post("")\n', '    menu_access: list[str] = Field(\n        default_factory=lambda: list(\n            MENU_KEYS\n        )\n    )\n    menu_permissions: dict[\n        str,\n        list[str],\n    ] | None = None\n\n\n@users_router.post("")\n')

replace_once('backend/auth.py', '    uid = new_id()\n\n    doc = {\n', '    explicit_permissions = None\n\n    if (\n        body.menu_permissions\n        is not None\n    ):\n        if (\n            user.get("role")\n            not in (\n                "master_admin",\n                "admin",\n            )\n        ):\n            raise HTTPException(\n                status_code=403,\n                detail=(\n                    "Only Master Admin and Admin "\n                    "can set granular permissions"\n                ),\n            )\n\n        explicit_permissions = (\n            _validate_delegated_menu_permissions(\n                user,\n                menu_access,\n                body.menu_permissions,\n            )\n        )\n\n    uid = new_id()\n\n    doc = {\n')

replace_once('backend/auth.py', '    if profile:\n        doc["role_profile_id"] = (\n', '    if explicit_permissions is not None:\n        doc["menu_permissions"] = (\n            explicit_permissions\n        )\n\n    if profile:\n        doc["role_profile_id"] = (\n')

replace_once('backend/inventory_routes.py', 'from auth import get_current_user, require_roles\n\n\nrouter = APIRouter(prefix="/api")\nMANAGE = require_roles("admin", "supervisor")\n', 'from auth import require_menu_permission\nfrom public_inventory_category_routes import ensure_category_link\n\n\nrouter = APIRouter(prefix="/api")\nVIEW = require_menu_permission("inv", "view")\nADD = require_menu_permission("inv", "add")\nEDIT = require_menu_permission("inv", "edit")\nDELETE = require_menu_permission("inv", "delete")\n')

text = read('backend/inventory_routes.py')
text = text.replace('user: dict = Depends(get_current_user),', 'user: dict = Depends(VIEW),')
text = text.replace('user: dict = Depends(MANAGE),', 'user: dict = Depends(EDIT),')
# create uses ADD, delete uses DELETE after broad MANAGE->EDIT replacement
old = '''@router.post("/inventory")\nasync def create_item(\n    body: ItemBody,\n    user: dict = Depends(EDIT),\n):'''
new = '''@router.post("/inventory")\nasync def create_item(\n    body: ItemBody,\n    user: dict = Depends(ADD),\n):'''
if old not in text:
    raise SystemExit('ABORT: create Inventory permission marker not found')
text = text.replace(old, new, 1)
old = '''@router.delete("/inventory/{iid}")\nasync def delete_item(\n    iid: str,\n    user: dict = Depends(EDIT),\n):'''
new = '''@router.delete("/inventory/{iid}")\nasync def delete_item(\n    iid: str,\n    user: dict = Depends(DELETE),\n):'''
if old not in text:
    raise SystemExit('ABORT: delete Inventory permission marker not found')
text = text.replace(old, new, 1)
write('backend/inventory_routes.py', text)

replace_once('backend/inventory_routes.py', '    await audit_log(\n        "inventory",\n        doc["id"],\n        "inventory.create",\n', '    if doc.get("category"):\n        await ensure_category_link(\n            doc["category"],\n            user,\n        )\n\n    await audit_log(\n        "inventory",\n        doc["id"],\n        "inventory.create",\n')

replace_once('backend/inventory_routes.py', '    if change:\n        await db.inventory_transactions.insert_one(\n', '    if payload.get("category"):\n        await ensure_category_link(\n            payload["category"],\n            user,\n        )\n\n    if change:\n        await db.inventory_transactions.insert_one(\n')

replace_once('backend/export_routes.py', 'from auth import get_current_user\n', 'from auth import get_current_user, has_menu_permission\n')

text = read('backend/export_routes.py')
marker = '''    await require_feature_enabled(\n        "export_data"\n    )\n\n    params = _params'''
replacement = '''    await require_feature_enabled(\n        "export_data"\n    )\n\n    if (\n        dataset == "inventory"\n        and not has_menu_permission(\n            user,\n            "inv",\n            "view",\n        )\n    ):\n        raise HTTPException(\n            status_code=403,\n            detail="Inventory view permission required",\n        )\n\n    params = _params'''
count = text.count(marker)
if count != 2:
    raise SystemExit(f'ABORT: expected 2 export permission markers, found {count}')
write('backend/export_routes.py', text.replace(marker, replacement))

replace_once('backend/server.py', 'from public_inventory_routes import router as public_inventory_router\nfrom settings_routes import router as settings_router\n', 'from public_inventory_routes import router as public_inventory_router\nfrom public_inventory_category_routes import router as public_inventory_category_router\nfrom settings_routes import router as settings_router\n')

replace_once('backend/server.py', 'app.include_router(public_inventory_router)\napp.include_router(settings_router)\n', 'app.include_router(public_inventory_router)\napp.include_router(public_inventory_category_router)\napp.include_router(settings_router)\n')

replace_once('backend/server.py', '    await db.role_profiles.create_index(\n        "name_key",\n        unique=True,\n        name="uniq_role_profiles_name",\n    )\n\n    await db.auth_sessions.create_index("jti_hash", unique=True, name="uniq_auth_session_jti")\n', '    await db.role_profiles.create_index(\n        "name_key",\n        unique=True,\n        name="uniq_role_profiles_name",\n    )\n\n    await db.public_inventory_category_links.create_index(\n        "id",\n        unique=True,\n        name="uniq_public_inventory_category_id",\n    )\n    await db.public_inventory_category_links.create_index(\n        "category_key",\n        unique=True,\n        name="uniq_public_inventory_category_name",\n    )\n    await db.public_inventory_category_links.create_index(\n        "token_id",\n        unique=True,\n        name="uniq_public_inventory_category_token",\n    )\n\n    await db.auth_sessions.create_index("jti_hash", unique=True, name="uniq_auth_session_jti")\n')

replace_once('deploy/amt-update-runner', '    signature = STATE_ROOT / "release.sig"\n    try:\n        raw = base64.b64decode(signature_b64, validate=True)\n    except Exception as exc:\n        raise RuntimeError("Release signature is not valid Base64") from exc\n', '    signature = STATE_ROOT / "release.sig"\n\n    signature_b64 = "".join(\n        str(\n            signature_b64\n            or ""\n        ).split()\n    )\n\n    if not signature_b64:\n        raise RuntimeError(\n            "Release signature is empty"\n        )\n\n    try:\n        raw = base64.b64decode(\n            signature_b64,\n            validate=True,\n        )\n    except Exception as exc:\n        raise RuntimeError(\n            "Release signature is not valid Base64"\n        ) from exc\n')

replace_once('frontend/src/context/AuthContext.jsx', 'export const hasLicenseFeature = (\n', 'export const MENU_PERMISSION_OPERATIONS = [\n  "view",\n  "add",\n  "edit",\n  "delete",\n  "public",\n];\n\nexport const hasMenuPermission = (\n  user,\n  key,\n  operation = "view"\n) => {\n  if (!user) return false;\n\n  if (isMasterAdmin(user)) {\n    return true;\n  }\n\n  if (\n    !hasMenuAccess(\n      user,\n      key\n    )\n  ) {\n    return false;\n  }\n\n  const permissions =\n    user.menu_permissions;\n\n  if (\n    !permissions ||\n    typeof permissions !==\n      "object" ||\n    !Array.isArray(\n      permissions[key]\n    )\n  ) {\n    return true;\n  }\n\n  return permissions[\n    key\n  ].includes(operation);\n};\n\n\nexport const hasLicenseFeature = (\n')

replace_once('frontend/src/pages/Inventory.jsx', 'import {\n  useAuth,\n  canManage,\n  isAdmin,\n} from "@/context/AuthContext";\n', 'import {\n  useAuth,\n  hasMenuPermission,\n} from "@/context/AuthContext";\n')

replace_once('frontend/src/pages/Inventory.jsx', '  const { format } = useCurrency();\n  const [sp] = useSearchParams();\n\n  const [items, setItems] = useState([]);\n', '  const { format } = useCurrency();\n  const [sp] = useSearchParams();\n\n  const canAddInventory =\n    hasMenuPermission(\n      user,\n      "inv",\n      "add"\n    );\n  const canEditInventory =\n    hasMenuPermission(\n      user,\n      "inv",\n      "edit"\n    );\n  const canDeleteInventory =\n    hasMenuPermission(\n      user,\n      "inv",\n      "delete"\n    );\n  const canPublicInventory =\n    hasMenuPermission(\n      user,\n      "inv",\n      "public"\n    );\n\n  const [items, setItems] = useState([]);\n')

replace_once('frontend/src/pages/Inventory.jsx', '        {canManage(user) && (\n          <Btn\n', '        {canAddInventory && (\n          <Btn\n')

replace_once('frontend/src/pages/Inventory.jsx', '      {isAdmin(user) && (\n        <InventoryPublicAccess />\n      )}\n', '      {canPublicInventory && (\n        <InventoryPublicAccess\n          categories={categories}\n        />\n      )}\n')

replace_once('frontend/src/pages/Inventory.jsx', '            render: (item) =>\n              canManage(user) && (\n                <span className="whitespace-nowrap">\n                  <button\n                    onClick={() => setAdjust(item)}\n                    title="Adjust stock"\n                    className="mr-2 text-slate-400 hover:text-blue-600"\n                    data-testid={`adjust-${item.id}`}\n                  >\n                    <ArrowUpDown className="inline h-4 w-4" />\n                  </button>\n\n                  <button\n                    onClick={() => openEdit(item)}\n                    title="Edit"\n                    className="mr-2 text-slate-400 hover:text-blue-600"\n                    data-testid={`edit-item-${item.id}`}\n                  >\n                    <Pencil className="inline h-4 w-4" />\n                  </button>\n\n                  <button\n                    onClick={() => del(item)}\n                    title="Delete"\n                    className="text-slate-400 hover:text-red-600"\n                    data-testid={`delete-item-${item.id}`}\n                  >\n                    <Trash2 className="inline h-4 w-4" />\n                  </button>\n                </span>\n              ),\n', '            render: (item) =>\n              (\n                canEditInventory ||\n                canDeleteInventory\n              ) && (\n                <span className="whitespace-nowrap">\n                  {canEditInventory && (\n                    <>\n                      <button\n                        onClick={() =>\n                          setAdjust(\n                            item\n                          )\n                        }\n                        title="Adjust stock"\n                        className="mr-2 text-slate-400 hover:text-blue-600"\n                        data-testid={`adjust-${item.id}`}\n                      >\n                        <ArrowUpDown className="inline h-4 w-4" />\n                      </button>\n\n                      <button\n                        onClick={() =>\n                          openEdit(\n                            item\n                          )\n                        }\n                        title="Edit"\n                        className="mr-2 text-slate-400 hover:text-blue-600"\n                        data-testid={`edit-item-${item.id}`}\n                      >\n                        <Pencil className="inline h-4 w-4" />\n                      </button>\n                    </>\n                  )}\n\n                  {canDeleteInventory && (\n                    <button\n                      onClick={() =>\n                        del(item)\n                      }\n                      title="Delete"\n                      className="text-slate-400 hover:text-red-600"\n                      data-testid={`delete-item-${item.id}`}\n                    >\n                      <Trash2 className="inline h-4 w-4" />\n                    </button>\n                  )}\n                </span>\n              ),\n')

replace_once('frontend/src/App.js', 'import PublicInventory from "@/pages/PublicInventory";\n', 'import PublicInventory from "@/pages/PublicInventory";\nimport PublicInventoryCategory from "@/pages/PublicInventoryCategory";\n')

replace_once('frontend/src/App.js', '      <Route path="/q/inventory/:token" element={<PublicInventory />} />\n      <Route path="/login" element={<Login />} />\n', '      <Route path="/q/inventory/:token" element={<PublicInventory />} />\n      <Route path="/q/inventory-category/:token" element={<PublicInventoryCategory />} />\n      <Route path="/login" element={<Login />} />\n')

replace_once('frontend/src/pages/Users.jsx', 'import { fmtDate } from "@/lib/helpers";\n', 'import { fmtDate } from "@/lib/helpers";\nimport InventoryPermissionEditor, {\n  INVENTORY_PERMISSION_KEYS,\n} from "@/components/InventoryPermissionEditor";\n')

replace_once('frontend/src/pages/Users.jsx', '  menu_access: [...ALL_MENU_KEYS],\n};\n', '  menu_access: [...ALL_MENU_KEYS],\n  menu_permissions: {\n    inv: [\n      ...INVENTORY_PERMISSION_KEYS,\n    ],\n  },\n};\n')

replace_once('frontend/src/pages/Users.jsx', '  const [accessTarget, setAccessTarget] = useState(null);\n  const [accessValue, setAccessValue] = useState([]);\n', '  const [accessTarget, setAccessTarget] = useState(null);\n  const [accessValue, setAccessValue] = useState([]);\n  const [\n    accessInventoryPermissions,\n    setAccessInventoryPermissions,\n  ] = useState([\n    ...INVENTORY_PERMISSION_KEYS,\n  ]);\n')

replace_once('frontend/src/pages/Users.jsx', '      menu_access: [\n        ...delegableMenuKeys,\n      ],\n    });\n', '      menu_access: [\n        ...delegableMenuKeys,\n      ],\n      menu_permissions:\n        delegableMenuKeys.includes(\n          "inv"\n        )\n          ? {\n              inv: [\n                ...INVENTORY_PERMISSION_KEYS,\n              ],\n            }\n          : {},\n    });\n')

replace_once('frontend/src/pages/Users.jsx', '      const {\n        confirm_password,\n        ...payload\n      } = form;\n\n      await api.post(\n', '      const {\n        confirm_password,\n        ...payload\n      } = form;\n\n      if (!isAdmin(user)) {\n        delete payload.menu_permissions;\n      }\n\n      await api.post(\n')

replace_once('frontend/src/pages/Users.jsx', '        menu_access: [\n          ...delegableMenuKeys,\n        ],\n      });\n', '        menu_access: [\n          ...delegableMenuKeys,\n        ],\n        menu_permissions:\n          delegableMenuKeys.includes(\n            "inv"\n          )\n            ? {\n                inv: [\n                  ...INVENTORY_PERMISSION_KEYS,\n                ],\n              }\n            : {},\n      });\n')

replace_once('frontend/src/pages/Users.jsx', '  const openAccess = (target) => {\n    if (!canManageTarget(user, target)) return;\n\n    setAccessTarget(target);\n    const currentAccess =\n      Array.isArray(\n        target.menu_access\n      )\n        ? target.menu_access\n        : [\n            ...ALL_MENU_KEYS,\n          ];\n\n    setAccessValue(\n      delegableMenuKeys.filter(\n        (key) =>\n          currentAccess.includes(\n            key\n          )\n      )\n    );\n  };\n\n  const saveAccess = async () => {\n    if (!accessTarget) return;\n\n    try {\n      await api.patch(`/users/${accessTarget.id}/access`, {\n        menu_access: accessValue,\n      });\n      toast.success("Menu access updated");\n      setAccessTarget(null);\n      load();\n    } catch (error) {\n      toast.error(\n        formatApiError(error.response?.data?.detail)\n      );\n    }\n  };\n', '  const openAccess = (target) => {\n    if (\n      !isAdmin(user) ||\n      !canManageTarget(\n        user,\n        target\n      )\n    ) {\n      return;\n    }\n\n    setAccessTarget(target);\n\n    const currentAccess =\n      Array.isArray(\n        target.menu_access\n      )\n        ? target.menu_access\n        : [\n            ...ALL_MENU_KEYS,\n          ];\n\n    setAccessValue(\n      delegableMenuKeys.filter(\n        (key) =>\n          currentAccess.includes(\n            key\n          )\n      )\n    );\n\n    setAccessInventoryPermissions(\n      Array.isArray(\n        target\n          .menu_permissions\n          ?.inv\n      )\n        ? [\n            ...target\n              .menu_permissions\n              .inv,\n          ]\n        : currentAccess.includes(\n            "inv"\n          )\n          ? [\n              ...INVENTORY_PERMISSION_KEYS,\n            ]\n          : []\n    );\n  };\n\n  const saveAccess = async () => {\n    if (\n      !accessTarget ||\n      !isAdmin(user)\n    ) {\n      return;\n    }\n\n    try {\n      await api.patch(\n        `/users/${accessTarget.id}/permissions`,\n        {\n          menu_access:\n            accessValue,\n          menu_permissions:\n            accessValue.includes(\n              "inv"\n            )\n              ? {\n                  inv:\n                    accessInventoryPermissions,\n                }\n              : {\n                  inv: [],\n                },\n        }\n      );\n\n      toast.success(\n        "Access permissions updated"\n      );\n      setAccessTarget(null);\n      load();\n    } catch (error) {\n      toast.error(\n        formatApiError(\n          error.response?.data\n            ?.detail\n        )\n      );\n    }\n  };\n')

replace_once('frontend/src/pages/Users.jsx', '                        disabled={\n                          !manageable ||\n                          target.id === user.id ||\n                          target.role === "master_admin"\n                        }\n', '                        disabled={\n                          !isAdmin(user) ||\n                          !manageable ||\n                          target.id === user.id ||\n                          target.role === "master_admin"\n                        }\n')

replace_once('frontend/src/pages/Users.jsx', '                menu_access: [\n                  ...(\n                    profile.menu_access ||\n                    []\n                  ),\n                ],\n              });\n', '                menu_access: [\n                  ...(\n                    profile.menu_access ||\n                    []\n                  ),\n                ],\n                menu_permissions:\n                  (\n                    profile.menu_access ||\n                    []\n                  ).includes(\n                    "inv"\n                  )\n                    ? {\n                        inv: [\n                          ...INVENTORY_PERMISSION_KEYS,\n                        ],\n                      }\n                    : {},\n              });\n')

replace_once('frontend/src/pages/Users.jsx', '            onChange={(menu_access) =>\n              setForm({ ...form, menu_access })\n            }\n          />\n\n          <DialogFooter>\n', '            onChange={(menu_access) =>\n              setForm({\n                ...form,\n                menu_access,\n                menu_permissions:\n                  menu_access.includes(\n                    "inv"\n                  )\n                    ? {\n                        ...form.menu_permissions,\n                        inv:\n                          form\n                            .menu_permissions\n                            ?.inv\n                            ?.length\n                            ? form\n                                .menu_permissions\n                                .inv\n                            : [\n                                ...INVENTORY_PERMISSION_KEYS,\n                              ],\n                      }\n                    : {\n                        ...form.menu_permissions,\n                        inv: [],\n                      },\n              })\n            }\n          />\n\n          {isAdmin(user) &&\n            form.menu_access.includes(\n              "inv"\n            ) && (\n              <InventoryPermissionEditor\n                value={\n                  form\n                    .menu_permissions\n                    ?.inv ||\n                  []\n                }\n                onChange={(\n                  inv\n                ) =>\n                  setForm({\n                    ...form,\n                    menu_permissions:\n                      {\n                        ...form.menu_permissions,\n                        inv,\n                      },\n                  })\n                }\n                disabled={\n                  masterSelected\n                }\n              />\n            )}\n\n          <DialogFooter>\n')

replace_once('frontend/src/pages/Users.jsx', '        <DialogContent className="max-w-xl">\n          <DialogHeader>\n            <DialogTitle>\n              Menu Access — {accessTarget?.name}\n            </DialogTitle>\n          </DialogHeader>\n\n          <MenuCheckboxes\n            value={accessValue}\n            allowedKeys={\n              accessTarget?.role ===\n              "master_admin"\n                ? ALL_MENU_KEYS\n                : delegableMenuKeys\n            }\n            disabled={\n              accessTarget?.role ===\n                "master_admin"\n            }\n            onChange={setAccessValue}\n          />\n\n          <DialogFooter>\n', '        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">\n          <DialogHeader>\n            <DialogTitle>\n              Access Permissions — {accessTarget?.name}\n            </DialogTitle>\n          </DialogHeader>\n\n          <MenuCheckboxes\n            value={accessValue}\n            allowedKeys={\n              accessTarget?.role ===\n              "master_admin"\n                ? ALL_MENU_KEYS\n                : delegableMenuKeys\n            }\n            disabled={\n              accessTarget?.role ===\n                "master_admin"\n            }\n            onChange={(\n              nextAccess\n            ) => {\n              setAccessValue(\n                nextAccess\n              );\n\n              if (\n                nextAccess.includes(\n                  "inv"\n                ) &&\n                accessInventoryPermissions\n                  .length === 0\n              ) {\n                setAccessInventoryPermissions(\n                  [\n                    ...INVENTORY_PERMISSION_KEYS,\n                  ]\n                );\n              }\n\n              if (\n                !nextAccess.includes(\n                  "inv"\n                )\n              ) {\n                setAccessInventoryPermissions(\n                  []\n                );\n              }\n            }}\n          />\n\n          {accessValue.includes(\n            "inv"\n          ) && (\n            <InventoryPermissionEditor\n              value={\n                accessInventoryPermissions\n              }\n              onChange={\n                setAccessInventoryPermissions\n              }\n              disabled={\n                accessTarget?.role ===\n                  "master_admin"\n              }\n            />\n          )}\n\n          <DialogFooter>\n')

replace_once('frontend/src/pages/Users.jsx', '          roles keep a built-in permission level underneath, while Menu Access\n          remains configurable per user account.\n', '          roles keep a built-in permission level underneath, while Menu Access\n          remains configurable per user account. Master Admin and Admin can also\n          set granular Inventory View, Add, Edit/Adjust, Delete, and Public QR permissions.\n')

release = {
    'version': '1.2.0',
    'status': 'stable',
    'title': 'Category Cabinet QR & Granular Inventory Permissions',
    'summary': 'Added one secure public Inventory QR per category/cabinet and granular per-user Inventory permissions for View, Add, Edit/Adjust, Delete, and Public QR management.',
    'changes': [
        'Each Inventory category now has its own stable QR/Public Link for a physical cabinet.',
        'A new Inventory category automatically receives a new category QR link.',
        'Inventory QR management shows one View QR / Public Link action per category instead of one all-inventory QR.',
        'Each category public page is permanently scoped to that category and cannot switch to another category.',
        'Category public pages support search, Type, Stock Status, Storage Location, and sorting.',
        'Public category Excel/PDF exports keep the selected category scope and use the full Inventory report format including Unit Price and Stock Value.',
        'Category QR links can be copied, opened, reset, disabled, enabled, and downloaded as printable cabinet labels.',
        'Resetting one category link revokes only that category QR and does not affect other cabinets.',
        'Inventory menu access now defaults to full Inventory operations regardless of built-in/custom base role, preserving Storekeeper-style workflows.',
        'Master Admin and Admin can set per-user Inventory permissions: View, Add, Edit/Adjust, Delete, and Public QR.',
        'Inventory backend endpoints enforce the granular permissions, not only frontend button visibility.',
        'Inventory report export requires Inventory View permission.',
        'Users without explicit granular settings remain backward compatible: an existing Inventory menu assignment grants all Inventory operations by default.',
        'Tracked updater now normalizes harmless Base64 whitespace before strict digital-signature verification to prevent CRM line-wrap failures.',
    ],
}
history['versions'] = [release, *versions]
history_path.write_text(json.dumps(history, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')

replace_once('README.md', 'AMT uses semantic versions for production releases. These are product-facing summaries through **1.1.14**.\n\n### 1.1.14 - Public Inventory UX & PDF Metadata Fixes\n', 'AMT uses semantic versions for production releases. These are product-facing summaries through **1.2.0**.\n\n### 1.2.0 - Category Cabinet QR & Granular Inventory Permissions\n\n- Added one secure **QR / Public Link per Inventory category** for physical cabinets.\n- New categories automatically receive their own stable QR link.\n- Inventory shows **View QR / Public Link** per category, with Copy, Open, Download Cabinet Label, Reset, Disable, and Enable actions.\n- Public category pages are locked to their category and support Search, Type, Stock Status, Storage Location, sorting, Excel, and PDF.\n- Category PDF/Excel reports use the full Inventory report columns, including **Unit Price** and **Stock Value**.\n- Existing Inventory menu access now grants Inventory operations by default regardless of built-in/custom base role.\n- Master Admin and Admin can configure per-user Inventory **View / Add / Edit-Adjust / Delete / Public QR** permissions.\n- Backend Inventory routes enforce the granular permissions.\n- Inventory export requires Inventory View permission.\n- Existing users remain backward compatible when no granular permission override has been saved.\n- Updater source now normalizes Base64 whitespace before strict release-signature verification.\n\n### 1.1.14 - Public Inventory UX & PDF Metadata Fixes\n')

print('AMT 1.2.0 category QR + granular Inventory permissions patch applied successfully.')
print(f'Backup: {backup}')
print('Release: 1.2.0 stable')
