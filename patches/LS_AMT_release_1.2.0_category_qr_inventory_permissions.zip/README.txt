AMT 1.2.0

Feature release. Versioning rule:
- New feature -> next minor version (1.2.0)
- Revisions/fixes for this feature -> 1.2.1, 1.2.2, ...

Requires current Git main/documented version 1.1.14.

Includes:
- Per-category Inventory cabinet QR/Public Link
- Auto QR creation for new categories
- Category-scoped public Excel/PDF reports
- Granular Inventory permissions per user
- Storekeeper/custom-role Inventory CRUD based on menu permissions, not base role
- Public QR permission delegation
- Updater Base64 whitespace normalization source fix

IMPORTANT:
Clients still running an older updater that rejects CRM-wrapped Base64 must apply
HOTFIX_UPDATER_BASE64_BEFORE_1.2.0.sh once before installing 1.2.0.
