#!/bin/bash
set -euo pipefail

RUNNER="/usr/local/sbin/amt-update-runner"
BACKUP="/usr/local/sbin/amt-update-runner.bak-before-1.2.0"

[ "$(id -u)" -eq 0 ] || {
  echo "Run with sudo: sudo bash HOTFIX_UPDATER_BASE64_BEFORE_1.2.0.sh"
  exit 1
}

[ -f "$RUNNER" ] || {
  echo "Updater runner not found: $RUNNER"
  exit 1
}

if grep -q 'signature_b64 = "".join' "$RUNNER"; then
  echo "Updater Base64 normalization is already installed."
  python3 -m py_compile "$RUNNER"
  exit 0
fi

cp "$RUNNER" "$BACKUP"

python3 - "$RUNNER" <<'PY'
from pathlib import Path
import sys

p = Path(sys.argv[1])
text = p.read_text(encoding="utf-8")

old = '''    signature = STATE_ROOT / "release.sig"
    try:
        raw = base64.b64decode(signature_b64, validate=True)
    except Exception as exc:
        raise RuntimeError("Release signature is not valid Base64") from exc
'''

new = '''    signature = STATE_ROOT / "release.sig"

    signature_b64 = "".join(
        str(
            signature_b64
            or ""
        ).split()
    )

    if not signature_b64:
        raise RuntimeError(
            "Release signature is empty"
        )

    try:
        raw = base64.b64decode(
            signature_b64,
            validate=True,
        )
    except Exception as exc:
        raise RuntimeError(
            "Release signature is not valid Base64"
        ) from exc
'''

if old not in text:
    raise SystemExit(
        "ABORT: updater marker not found. "
        "Review the installed runner before changing it."
    )

p.write_text(
    text.replace(old, new, 1),
    encoding="utf-8",
)

print("Updater Base64 normalization installed.")
PY

chmod 755 "$RUNNER"
python3 -m py_compile "$RUNNER"

echo "Updater hotfix ready."
echo "Backup: $BACKUP"
